({
    searchHelper: function(component, event, helper,fields) {

        let objectAPIName=component.get("v.objectAPIName");
        //Server action
        let searchAction=component.get("c.searchRecords");
        //pass parametrs
        searchAction.setParams({
           searchKey:component.get("v.searchText"),
           fieldApi:component.get("v.searchFieldAPIName"),
           objectName:objectAPIName,
           displayFields:fields
          // requiredFields:queryFields
        });
        //set callback
        searchAction.setCallback(this,function(response){
            let state=response.getState();
            if(state==="SUCCESS"){
                //find the return data
                let data=response.getReturnValue();
                component.set("v.searchResults",data);
            }
            else{
                alert("ERROR"+JSON.Stringify(response.getError()));
            }

        });
        $A.enqueueAction(searchAction);
    },
    getSearchfieldHlp:function(component,event,helper){
      let objectAPIName = component.get("v.objectAPIName");
      let fieldsetAPIName = component.get("v.fieldSetName");

      let action = component.get("c.getDisplayFields");
      action.setParams({
        objectName : objectAPIName,
        fieldSetName : fieldsetAPIName
      });
      action.setCallback(this,function(response){
        let state = response.getState();
        if(state === "SUCCESS"){
            let results=response.getReturnValue();
            component.set("v.displayFields",results);
            helper.searchHelper(component,event,helper,results);
        }
      });
      $A.enqueueAction(action);
    }
})