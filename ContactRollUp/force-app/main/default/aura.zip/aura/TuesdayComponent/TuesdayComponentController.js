({
    knowYourAction : function(component, event, helper) {
        helper.searchHelper(component, event, helper);
    }
})
