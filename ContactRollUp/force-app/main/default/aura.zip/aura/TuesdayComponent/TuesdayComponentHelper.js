({
    searchHelper : function(component, event, helper) {
        let objectAPName = component.get("v.objectAPIName");
        //get search fields in return
        let queryFields = helper.getSearchFieldsHelp(objectAPName);
        component.set("v.displayFields", queryFields);
        //Server action
        let searchAction = component.get("c.searchRecords");
        //Pass your parameters
        searchAction.setParams({
            searchKey : component.get("v.searchText"),
            fieldApi : component.get("v.searchFieldAPIName"),
            objectName : objectAPName,
            requiredFields : queryFields
        });
        searchAction.setCallback(this, function(response){
            let state = response.getState();
            if(state === "SUCCESS"){
                //find the return data
                let data = response.getReturnValue();
                component.set("v.searchResults", data);
            }
            else{
                alert("ERROR"+JSON.stringify(response.getError()));
            }
        });
        $A.enqueueAction(searchAction);
    },
    getSearchFieldsHelp : function(objectName) {
        //How to define array
        if(objectName === "Account"){
            return ["Name", "Rating", "Phone", "Description"];
        }
        else if(objectName = "Contact"){
            return ["FirstName", "LastName", "Phone", "Email"];
        }
        else{
            return null;
        }
    }
})
