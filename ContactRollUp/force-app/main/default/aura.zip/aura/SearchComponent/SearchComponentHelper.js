({
    searchHelper : function(component, event, helper) {
        //How to get the attribute value from SearchInput area
        let searchValue = component.getReference("v.searchText");
        //Now how to pass value from attribute to Javascript function
        component.set("v.searchOutput", searchValue)
    }
})
