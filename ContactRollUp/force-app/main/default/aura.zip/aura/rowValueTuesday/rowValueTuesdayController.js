({
    doInit : function(component, event, helper) {
        let data = component.get("v.dataRecord");
        let fieldName = component.get("v.fieldName");
        component.set("v.fieldValue", data[fieldName]);
    }
})
